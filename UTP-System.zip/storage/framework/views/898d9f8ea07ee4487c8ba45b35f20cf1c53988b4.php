<?php
    $title = 'Register'; $chnge_req = 'required';
?>



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              <?php if(isset($user_update)): ?>
                <div class="card-header"><?php echo e(__('Update User')); ?></div>
              <?php else: ?>
                <div class="card-header"><?php echo e(__('New User')); ?></div>
              <?php endif; ?>

                <div class="card-body">
                    <?php if(isset($user_update)): ?>
                      <?php $chnge_req = ''; ?>
                    <form method="POST" id="save_update" action=" " method="POST" multiple enctype="multipart/form-data">
                    <?php else: ?>
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php endif; ?>
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="id" type="text" name="id" value="<?php if(isset($user_update)): ?><?php echo e($user_update->id); ?><?php endif; ?>" class="d-none">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php if(isset($user_update)): ?><?php echo e($user_update->name); ?><?php endif; ?>" autocomplete="off" required>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Email Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php if(isset($user_update)): ?><?php echo e($user_update->email); ?><?php endif; ?>" >

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" autocomplete="new-password" <?php echo e($chnge_req); ?>>

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" <?php echo e($chnge_req); ?> autocomplete="new-password">
                            </div>
                        </div>

                        <div class="row mb-0">
                          <?php if(isset($user_update)): ?>
                            <div class="col-md-6 offset-md-4">
                              <button id="update_user" type="submit" class="btn btn-primary">
                                <?php echo e(__('Update User')); ?>

                              </button>
                            </div>
                          <?php else: ?>
                            <div class="col-md-6 offset-md-4">
                              <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Save User')); ?>

                              </button>
                            </div>
                          <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
  let _token=$("input[name=\"_token\"]").val()
  $("#update_user").on("click",function(t){
    t.preventDefault();
    let data = new FormData($("#save_update")[0]);
    $.ajax({
      url:"<?php echo e(route('update_user_now')); ?>",
      method:"post",
      enctype:"multipart/form-data",
      processData:!1,
      cache:!1,
      contentType:!1,
      data:data,
      success:function(t){
        Swal.fire({
          position:"center",
          icon:"success",
          title:t.msg,
          showConfirmButton:!1,
          timer:1500
        })
      }
    })
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\portfolio\UTP-System\resources\views/auth/register.blade.php ENDPATH**/ ?>