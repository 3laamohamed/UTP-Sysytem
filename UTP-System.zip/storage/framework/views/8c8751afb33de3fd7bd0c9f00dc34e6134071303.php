<?php
    $title = 'Sort Services';
?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <div class="col-md-4 my-3">
        <label for="project" class="form-label">Select Group</label>
        <select class="form-select" id='project' name="project" required>
          <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($group->id); ?>"><?php echo e($group->group); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="sort-projects">
        <ul id="sortable">
          <?php echo csrf_field(); ?>
          <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="ui-state-default" data-id="<?php echo e($service->id); ?>">
            <img src="<?php echo e(asset('Admin/Services/' . $service->image)); ?>"/>
            <p><?php echo e($service->title); ?></p>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <div class="col-md-6 mx-auto">
        <button class="btn btn-success w-100" id="save_sort"> Save </button>
      </div>
    </div>
</div>

<script>
  let _token=$("input[name=\"_token\"]").val();
  $('#project').on('change', function () {
    let id = $(this).val();
    let html = ''
    $.ajax({
      url: "<?php echo e(route('admin.save_get_sort_services')); ?>",
      method: "post",
      data: {
        _token,
        id
      },
      success: function(data) {
        if(data.status == 'true'){
          $('#sortable').html('');
          data.services.forEach(service => {
          html += `<li class="ui-state-default" data-id="${service.id}">
            <img src="<?php echo e(asset('Admin/Services/${service.image}')); ?>"/>
            <p>${service.title}</p>
          </li>`
          });
          $('#sortable').html(html);
        }
      }
    });
  });
  $(function () {
      $("#sortable").sortable();
      $("#sortable").disableSelection();
      $('#save_sort').on('click', function() {
        let sortArr = []
        let group = $('#project').val()
        $('#sortable li').each(function () {
            sortArr.push($(this).attr('data-id'));
        });
        $.ajax({
          url: "<?php echo e(route('admin.save_sort_services')); ?>",
          method: "post",
          data: {
            _token,
            projects:sortArr,
            group,
          },
          success: function(data) {
            if(data.status == 'true'){
              Swal.fire({
                position:"center",
                icon:"success",
                title:data.msg,
                showConfirmButton:!1,
                timer:1500
              })
            }
          }
        });
      });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\portfolio\UTP-System\resources\views/admin/sort_services.blade.php ENDPATH**/ ?>