<?php
  $title = 'About';
?>

<?php $__env->startSection('content'); ?>
<!-- Start About -->
<section class="about py-5 position-relative">
  <div class="container">
    <h2 class="special-title">About</h2>
    <div class="row">
      <div class="col-md-6">
        <img src="<?php echo e(asset('global/images/about.png')); ?>" alt="About" class="img-fluid">
      </div>
      <div class="col-md-6">
        <p class="lead">
          <?php if(isset($about->about)): ?>
            <?php echo e($about->about); ?>

          <?php endif; ?>
        </p>
      </div>
    </div>
  </div>
  <div class="shapes circle-shape first"></div>
  <div class="shapes dots-shape"></div>
  <div class="shapes triangle-shape"></div>
  <div class="shapes circle-shape last"></div>
</section>
<!-- End About -->

<!-- Start Team Section -->
<section class="Team py-5 position-relative">
  <div class="container">
    <h2 class="special-title">Our Team</h2>
    <div class="row">
      <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-xl-3 col-lg-4 col-md-6 my-5">
        <div class="team-box">
          <div class="team-image">
            <img src="<?php echo e(asset('Admin/Team/' . $per->image)); ?>"alt="team">
          </div>
          <h3 class="team-title"><?php echo e($per->name); ?></h3>
          <p><?php echo e($per->note); ?></p>
          <a href="<?php echo e($per->email); ?>" target="_blank" class="team-spocail text-center mb-3"><i
              class="fa-brands fa-linkedin fa-fw fa-3x"></i></a>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</section>
<!-- End Team Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\portfolio\UTP-System\resources\views/main/about.blade.php ENDPATH**/ ?>