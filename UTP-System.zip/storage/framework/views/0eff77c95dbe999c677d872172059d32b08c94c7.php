<?php
    $title = 'Details';
?>


<?php $__env->startSection('content'); ?>
<div class="container">
    
    <h2 class="title">Details</h2>
    <div class="row mt-3">
      <form  id="details_form" action=" " method="POST" multiple enctype="multipart/form-data">
        <div class="row align-items-end">
          <div class="col-md-4 mt-3">
            <label for="project" class="form-label">Select Project</label>
            <select class="form-select" id='project' name="project" required>
              <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($project->id); ?>"><?php echo e($project->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="col-md-4 mt-3">
            <div>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="section_id" value="" id='section_id'>
                <label for="project_name" class="form-label">Project Section</label>
                <input type="text" class="form-control" name="label" id="section_name" placeholder="Please Enter Project Section" required>
            </div>
          </div>
          <div class="col-md-4 mt-3">
            <input multiple id="album" name="images[]" type="file" onchange="previewImages(this, this.parentElement.nextElementSibling)"/>
          </div>
          <div id="preview" class="d-flex flex-wrap mt-3 mb-5" style='gap: 10px'></div>
        </div>
      </form>
      <div class="d-grid gap-2 col-6 mx-auto">
          <button class="btn btn-success clicked" id="save_details" type="button">Save</button>
          <button class="btn btn-primary clicked d-none" id="update_details" type="button">Update</button>
      </div>
    </div>
    <table class="table mt-4 text-center shadow-lg">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Section</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody class="table-light">
          <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="<?php echo e($section->id); ?>">
                <td><?php echo e($section->id); ?></td>
                <td><?php echo e($section->name); ?></td>
                <td>
                    <button class="table-buttons" onclick="getRow(<?php echo e($section->id); ?>)">
                        <ion-icon class="text-primary" name="create-outline"></ion-icon>
                    </button>
                    <button class="table-buttons" id='delete_section'>
                        <ion-icon class="text-danger" name="trash-outline"></ion-icon>
                    </button>
                </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<script>
let rowId,_token=$("input[name=\"_token\"]").val(),projectId=$("#project").find("option:first-child").attr("value");$("#project").on("change",function(){let a=$("#project").val();$.ajax({url:"<?php echo e(route('admin.search.all.section')); ?>",method:"post",enctype:"multipart/form-data",data:{_token,project:a},success:function(a){if("true"==a.status){let c="";for(var b=0;b<a.msg.length;b++)c+=`<tr id="${a.msg[b].id}"><td>${a.msg[b].id}</td><td>${a.msg[b].name}</td><td><button class="table-buttons" onclick="getRow(${a.msg[b].id})"><ion-icon class="text-primary" name="create-outline"></ion-icon></button><button class="table-buttons" id='delete_section'><ion-icon class="text-danger" name="trash-outline"></ion-icon></button></td></tr>`;$("tbody").html(c)}}})}),$("#save_details").on("click",function(a){a.preventDefault();let b=$("tbody").html(),c=new FormData($("#details_form")[0]);$.ajax({url:"<?php echo e(route('admin.save.details.project')); ?>",method:"post",enctype:"multipart/form-data",processData:!1,cache:!1,contentType:!1,data:c,success:function(a){"true"==a.status&&($("#preview").html(""),b+=`<tr id="${a.msg}"><td>${a.msg}</td><td>${$("#section_name").val()}</td><td><button class="table-buttons" onclick="getRow(${a.msg})"><ion-icon class="text-primary" name="create-outline"></ion-icon></button><button class="table-buttons" id='delete_group'><ion-icon class="text-danger" name="trash-outline"></ion-icon></button></td></tr>`,$("tbody").html(b),document.getElementById("details_form").reset(),$("#project").val(projectId).change(),Swal.fire({position:"center",icon:"success",title:"Saved Section",showConfirmButton:!1,timer:1500}))}})}),$("body").on("click","#delete_section",function(){let a=$(this).parents("tr").attr("id");Swal.fire({title:"Are you sure?",text:"You won't delete this section",icon:"warning",showCancelButton:!0,confirmButtonColor:"#3085d6",cancelButtonColor:"e#d33",confirmButtonText:"Yes, dlete it!"}).then(b=>{b.isConfirmed&&$.ajax({url:"<?php echo e(route('admin.del.section')); ?>",method:"post",enctype:"multipart/form-data",data:{_token,section:a},success:function(b){(b.status="true")&&($(`tr#${a}`).remove(),Swal.fire({position:"center",icon:"success",title:b.msg,showConfirmButton:!1,timer:1500}))}})})});function getRow(a){let b="";$.ajax({url:"<?php echo e(route('admin.get.update.details')); ?>",method:"post",enctype:"multipart/form-data",data:{_token,id:a},success:function(c){"true"===c.status&&(rowId=a,$("#section_name").val(c.section),$("#save_details").addClass("d-none"),$("#update_details").removeClass("d-none"),$("#section_id").val(rowId),c.images.forEach(a=>{b+=`<div class='text-center flex-grow-1'><i class="file-image"><input autocomplete="off" type="file" title="${a.image}" /><i class="reset" onclick="delDetailsImg('${a.image}', ${a.id}, this)"></i><div id='item-image'><label for="image" class="image unvisibile" style="background-image: url(<?php echo e(URL::asset('Admin/Details/${a.image}')); ?>)"></label></div></i></div>`}),$("#preview").html(b),window.scrollTo({top:0,behavior:"smooth"}))}})}function delDetailsImg(a,b,c){let d=c.parentElement.parentElement;Swal.fire({title:"Are you sure?",text:"You won't delete this Image",icon:"warning",showCancelButton:!0,confirmButtonColor:"#3085d6",cancelButtonColor:"e#d33",confirmButtonText:"Yes, dlete it!"}).then(c=>{c.isConfirmed&&$.ajax({url:"<?php echo e(route('admin.del.image.details')); ?>",method:"post",enctype:"multipart/form-data",data:{_token,id:b,image:a},success:function(a){(a.status="true")&&(Swal.fire({position:"center",icon:"success",title:a.msg,showConfirmButton:!1,timer:1500}),d.remove())}})})}$("body").on("click","#update_details",function(){let a=new FormData($("#details_form")[0]);$.ajax({url:"<?php echo e(route('admin.update.image.details')); ?>",method:"post",enctype:"multipart/form-data",processData:!1,cache:!1,contentType:!1,data:a,success:function(a){"true"==a.status&&(Swal.fire({position:"center",icon:"success",title:a.msg,showConfirmButton:!1,timer:1500}),$("#project").val(projectId).change(),$(`tr#${rowId}`).find("td:nth-child(2)").html($("#section_name").val()),$("#save_details").removeClass("d-none"),$("#update_details").addClass("d-none"),$("#preview").html(""),document.getElementById("details_form").reset())}})});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\UTP-System\resources\views/admin/details_project.blade.php ENDPATH**/ ?>