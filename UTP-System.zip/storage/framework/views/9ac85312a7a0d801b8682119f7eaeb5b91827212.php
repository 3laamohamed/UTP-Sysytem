<?php
  $title = 'Services';
?>

<?php $__env->startSection('content'); ?>
  <!-- Start Team Section -->
  <section class="py-5">
    <div class="container">
      <h2 class="special-title"><?php echo e($group->group); ?></h2>
      <div class="row">
        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-3 col-lg-4 col-md-6 my-5">
          <div class="service-box">
            <div class="service-image">
              <img src="<?php echo e(asset('Admin/Services/' . $service->image)); ?>" alt="service">
            </div>
            <h3 class="service-title"><?php echo e($service->title); ?></h3>
            <p><?php echo e($service->disc); ?></p>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section>
  <!-- End Team Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\portfolio\UTP-System\resources\views/main/services.blade.php ENDPATH**/ ?>