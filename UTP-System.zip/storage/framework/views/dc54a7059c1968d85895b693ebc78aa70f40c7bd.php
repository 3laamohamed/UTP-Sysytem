<?php $__env->startSection('content'); ?>
  <div class="container">
    <h2 class="title">Roles Management</h2>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-right mb-2">
              <a class="btn btn-success" href="<?php echo e(route('roles.create')); ?>"> Create New Role </a>
            </div>
        </div>
    </div>


    <?php if($message = Session::get('success')): ?>
          <script>
            Swal.fire({position:"center",icon:"success",title:'Saved Data',showConfirmButton:!1,timer:1500})
          </script>
    <?php endif; ?>


    <table class="table table-bordered">
        <tr class="table-dark">
            <th>No</th>
            <th>Name</th>
            <th width="200px">Action</th>
        </tr>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($role->name); ?></td>
                <td>
                  <a class="btn btn-primary" href="<?php echo e(route('roles.edit',$role->id)); ?>">Edit</a>
                  <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy', $role->id],'style'=>'display:inline']); ?>

                  <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                  <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <?php echo $roles->render(); ?>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\portfolio\UTP-System\resources\views/roles/index.blade.php ENDPATH**/ ?>