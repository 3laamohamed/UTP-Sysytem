<?php
  $title = 'Social';
?>


<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row mt-3">
    <div class="col-md-6 offset-md-3">
      <div class="mb-3">
        <?php echo csrf_field(); ?>
        <label for="facebook" class="form-label">Facebook</label>
        <?php if(isset($social->facebook)): ?>
        <input type="text" value='<?php echo e($social->facebook); ?>' class="form-control" id="facebook" placeholder="https://www.facebook.com/userName" required>
        <?php else: ?>
        <input type="text" class="form-control" id="facebook" placeholder="https://www.facebook.com/userName" required>
        <?php endif; ?>
      </div>
      <div class="mb-3">
        <label for="gmail" class="form-label">Gmail</label>
        <?php if(isset($social->gmail)): ?>
        <input type="text" value='<?php echo e($social->gmail); ?>' class="form-control" id="gmail" placeholder="Example123@gmail.com">
        <?php else: ?>
        <input type="text" class="form-control" id="gmail" placeholder="Example123@gmail.com">
        <?php endif; ?>
      </div>
      <div class="mb-3">
        <label for="linked_in" class="form-label">Linked in</label>
        <?php if(isset($social->linkedin)): ?>
        <input type="text" value='<?php echo e($social->linkedin); ?>' class="form-control" id="linked_in" placeholder="https://www.linkedin.com/in/userName">
        <?php else: ?>
        <input type="text" class="form-control" id="linked_in" placeholder="https://www.linkedin.com/in/userName">
        <?php endif; ?>
      </div>
      <div class="mb-3">
        <label for="whatsapp" class="form-label">whatsapp</label>
        <?php if(isset($social->whats)): ?>
        <input type="text" value='<?php echo e($social->whats); ?>' class="form-control" id="whatsapp" placeholder="201000000000">
        <?php else: ?>
        <input type="text" class="form-control" id="whatsapp" placeholder="201000000000">
        <?php endif; ?>
      </div>
      <div class="mb-3">
        <label for="twitter" class="form-label">twitter</label>
        <?php if(isset($social->twitter)): ?>
        <input type="text" value='<?php echo e($social->twitter); ?>' class="form-control" id="twitter" placeholder="https://www.twitter.com/userName">
        <?php else: ?>
        <input type="text" class="form-control" id="twitter" placeholder="https://www.twitter.com/userName">
        <?php endif; ?>
      </div>
      <div class="d-grid gap-2 col-6 mx-auto">
        <button class="btn btn-success clicked" id="save_social" type="button">Save</button>
      </div>
    </div>
  </div>
</div>
<script>
let _token=$("input[name=\"_token\"]").val();$("#save_social").on("click",function(){let a=$("#facebook").val(),b=$("#gmail").val(),c=$("#linked_in").val(),d=$("#whatsapp").val(),e=$("#twitter").val();$.ajax({url:"<?php echo e(route('admin.save.social')); ?>",method:"post",enctype:"multipart/form-data",data:{_token,facebook:a,gmail:b,linked_in:c,whatsapp:d,twitter:e},success:function(a){"true"==a.status&&Swal.fire({position:"center",icon:"success",title:a.msg,showConfirmButton:!1,timer:1500})}})});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\portfolio\UTP-System\resources\views/admin/general.blade.php ENDPATH**/ ?>