<?php
    $title = 'Sort Projects';
?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="title">Sort</h2>
    <div class="row">
      <div class="sort-projects">
        <ul id="sortable">
          <?php echo csrf_field(); ?>
          <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="ui-state-default" data-id="<?php echo e($project->id); ?>">
            <img src="<?php echo e(asset('Admin/Projects/' . $project->image)); ?>"/>
            <p><?php echo e($project->title); ?></p>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <div class="col-md-6 mx-auto">
        <button class="btn btn-success w-100" id="save_sort"> Save </button>
      </div>
    </div>
</div>

<script>
  let _token=$("input[name=\"_token\"]").val()
  $(function () {
      $("#sortable").sortable();
      $("#sortable").disableSelection();
      $('#save_sort').on('click', function() {
        let sortArr = []
        $('#sortable li').each(function () {
            sortArr.push($(this).attr('data-id'));
        });
        $.ajax({
          url: "<?php echo e(route('admin.save_sort_project')); ?>",
          method: "post",
          data: {
            _token,
            projects:sortArr
          },
          success: function(data) {
            if(data.status == 'true'){
              Swal.fire({
                position:"center",
                icon:"success",
                title:data.msg,
                showConfirmButton:!1,
                timer:1500
              })
            }
          }
        });
      });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\UTP-System\resources\views/admin/sort_projects.blade.php ENDPATH**/ ?>