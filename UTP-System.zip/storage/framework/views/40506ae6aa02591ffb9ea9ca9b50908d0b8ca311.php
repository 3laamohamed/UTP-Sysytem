<?php
  $title = 'Contact';
?>

<?php $__env->startSection('content'); ?>
<!-- Start Map Section -->
<div class="mapouter">
  <div class="gmap_canvas">
    <iframe
      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3454.1231679264115!2d31.210473099999998!3d30.0333241!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x145846d1379c9623%3A0xb1b1afcba8f6f1a2!2s20%20Ahmed%20Al%20Shatouri%2C%20Ad%20Doqi%2C%20Dokki%2C%20Giza%20Governorate%203750232!5e0!3m2!1sen!2seg!4v1664479803689!5m2!1sen!2seg"
      width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"
      referrerpolicy="no-referrer-when-downgrade"></iframe>
  </div>
</div>
<!-- End Map Section -->

<!-- Start Contact Us Section -->
<section class="contact-us pb-4">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="contact-info">
          <h4 class="my-4 main-color fw-bold">Contact Info</h4>
          <ul class="contact-us p-0">
            <li class="py-2">
              <?php if(!empty($social->whats)): ?>
              <a href="tel:+<?php echo e($social->whats); ?>" class=" text-muted">
                <i class="px-2 fa-solid fa-phone text-muted"></i>
                  <span><?php echo e($social->whats); ?></span>
              </a>
              <?php endif; ?>
            </li>
            <li class="py-2">
              <?php if(!empty($social->gmail)): ?>
              <a href="mailto:<?php echo e($social->gmail); ?>" class=" text-muted">
                <i class="px-2 fa-solid fa-envelope text-muted"></i>
                <span><?php echo e($social->gmail); ?></span>
              </a>
              <?php endif; ?>
            </li>
            <li class="py-2">
              <a href="https://maps.app.goo.gl/ciDkUnNm3E6iZ7Cx8" class="text-muted" target="_blank">
                <i class="px-2 fa-solid fa-map-location-dot text-muted"></i>
                <span>20 Ahmed Al Shatouri, Ad Doqi, Dokki, Giza Governorate 3750232</span>
              </a>
            </li>
          </ul>
          <h4 class="my-4 main-color fw-bold"> Get Social </h4>
          <div class="contact-social">
            <?php if(!empty($social->facebook)): ?>
              <a href="<?php echo e($social->facebook); ?>" class="text-muted facebook"><i class="fa-brands fa-facebook-f fa-fw fa-lg"></i></a>
            <?php endif; ?>
            <?php if(!empty($social->twitter)): ?>
              <a href="<?php echo e($social->twitter); ?>" class="text-muted twitter"><i class="fa-brands fa-twitter fa-fw fa-lg"></i></a>
            <?php endif; ?>
            <?php if(!empty($social->linkedin)): ?>
              <a href="<?php echo e($social->linkedin); ?>" class="text-muted linkedin"><i class="fa-brands fa-linkedin-in fa-fw fa-lg"></i></a>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <div class="col-md-8">
        <div class="contact-form">
          <?php echo csrf_field(); ?>
            <h4 class="my-4 main-color fw-bold">Contact With Us</h4>
            <div class="form-group mb-2">
              <label for="user_name" class="control-label mb-1">Your Name</label>
              <input type="text" id="user_name" name="user_email" class="form-control">
            </div>
            <div class="form-group mb-2">
              <label for="user_email" class="control-label mb-1">Your Email</label>
              <input type="text" id="user_email" name="user_email" class="form-control">
            </div>
            <div class="form-group mb-2">
              <label for="user_phone" class="control-label mb-1">Your Phone</label>
              <input type="text" id="user_phone" name="user_phone" class="form-control">
            </div>
            <div class="form-group mb-2">
              <label for="message" class="control-label mb-1">Your Message</label>
              <textarea id="message" name="message" class="form-control" rows="5"></textarea>
            </div>
            <button class="main-btn py-2 px-4 rounded-2" id="save_message" type="submit">Send</button>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- End Contact Us Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\portfolio\UTP-System\resources\views/main/contact_us.blade.php ENDPATH**/ ?>