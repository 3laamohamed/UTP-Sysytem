<?php
    $title = 'Contact';
?>


<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="cards-grid mt-3">
    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card shadow" cardId="<?php echo e($contact->id); ?>">
      <ion-icon class="icon-back"  name="chatbubbles-outline"></ion-icon>
      <div class="card-header d-flex align-items-center justify-content-between">
        <small class="text-muted"><?php echo e($contact->created_at); ?></small>
        <button id="del-mesg" class="d-flex align-items-center justify-content-center p-2">
          <ion-icon class="text-white" name="trash-outline"></ion-icon>
        </button>
      </div>
      <div class="card-body">
        <h3 class="card-title"><?php echo e($contact->name); ?></h3>
        <h5><?php echo e($contact->email); ?></h5>
        <h5><?php echo e($contact->phone); ?></h5>
        <blockquote class="blockquote mb-0">
        <p class="blockquote-footer mt-2"><?php echo e($contact->disc); ?></p>
        </blockquote>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<script>
$("body").on("click","#del-mesg",function(){let e=$(this).parents(".card");var o=$('input[name="_token"]').val();Swal.fire({title:"Are you sure?",text:"You won't delete this Message",icon:"warning",showCancelButton:!0,confirmButtonColor:"#3085d6",cancelButtonColor:"e#d33",confirmButtonText:"Yes, dlete it!"}).then(t=>{t.isConfirmed&&$.ajax({url:"<?php echo e(route('admin.delete.contact')); ?>",method:"post",enctype:"multipart/form-data",data:{_token:o,cardId:e.attr("cardId")},success:function(t){e.remove(),Swal.fire({position:"center",icon:"success",title:t.msg,showConfirmButton:!1,timer:1500})}})})});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\portfolio\UTP-System\resources\views/admin/contact.blade.php ENDPATH**/ ?>