<?php
    $title = 'Sort Groups';
?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <div class="sort-projects">
        <ul id="sortable">
          <?php echo csrf_field(); ?>
          <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="ui-state-default" data-id="<?php echo e($group->id); ?>">
            <img src="<?php echo e(asset('Admin/Services/' . $group->image)); ?>"/>
            <p><?php echo e($group->group); ?></p>
          </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <div class="col-md-6 mx-auto">
        <button class="btn btn-success w-100" id="save_sort"> Save </button>
      </div>
    </div>
</div>

<script>
  let _token=$("input[name=\"_token\"]").val()
  $(function () {
      $("#sortable").sortable();
      $("#sortable").disableSelection();
      $('#save_sort').on('click', function() {
        let sortArr = []
        $('#sortable li').each(function () {
            sortArr.push($(this).attr('data-id'));
        });
        $.ajax({
          url: "<?php echo e(route('admin.save_group_services')); ?>",
          method: "post",
          data: {
            _token,
            projects:sortArr
          },
          success: function(data) {
            if(data.status == 'true'){
              Swal.fire({
                position:"center",
                icon:"success",
                title:data.msg,
                showConfirmButton:!1,
                timer:1500
              })
            }
          }
        });
      });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\portfolio\UTP-System\resources\views/admin/sort_group.blade.php ENDPATH**/ ?>