<?php
    $title = 'Our Team';
?>


<?php $__env->startSection('content'); ?>
<div class="container">
  <h2 class="title">Our Team<h2>
  <div class="row mt-3">
    <div class="col-md-10 offset-md-1">
    <form id="form_save_service" action=" " method="POST" multiple enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="row align-items-start about">
        <div class="col-md-6">
          <div class="mb-3">
              <label for="service_name" class="form-label">Name</label>
              <input type="text"  class="form-control" name='name' id="service_name" placeholder="Please Enter Person Name">
          </div>
          <div class="mb-3">
            <label for="discription" class="form-label">description</label>
            <textarea class="form-control mt-3" name='disc' placeholder="Write Your Discription" id="discription" style="min-height: 250px;height: 250px"></textarea>
          </div>
        </div>
        <div class="col-md-6">
          <div class="mb-3">
            <input type="hidden" name="service_id" value="" id='service_id'>
            <label for="email" class="form-label">Email</label>
            <input type="text"  class="form-control" name='email' id="email" placeholder="Please Enter Person Email">
          </div>
          <!-- Upload Image -->
          <div class='text-center'>
            <i class="file-image">
              <input autocomplete="off" id="image" name="image" type="file" onchange="readImage(this)" title="" />
              <i class="reset" onclick="resetImage(this.previousElementSibling)"></i>
              <div id='item-image'>
                <label for="image" class="image"  data-label="Add Image"></label>
              </div>
            </i>
          </div>
        </div>
      </div>
    </form>
      <div class="d-grid gap-2 col-6 mx-auto mt-4">
        <button class="btn btn-success clicked" id="save_service" type="button">Save</button>
        <button class="btn btn-primary clicked d-none" id="update_service" type="button">Update</button>
      </div>
      <table class="table mt-4 text-center shadow-lg" style="font-size: 1rem;">
        <thead class="table-dark">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody class="table-light">
          <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr id="<?php echo e($person->id); ?>">
            <td><?php echo e($person->id); ?></td>
            <td><?php echo e($person->name); ?></td>
            <td>
              <button class="table-buttons" onclick="getRow(<?php echo e($person->id); ?>)">
                <ion-icon class="text-primary" name="create-outline"></ion-icon>
              </button>
              <button class="table-buttons" id='delete_service'>
                <ion-icon class="text-danger" name="trash-outline"></ion-icon>
              </button>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
<script>
let rowId,_token=$("input[name=\"_token\"]").val();$("#save_service").on("click",function(){let a=new FormData($("#form_save_service")[0]),b=$("tbody").html();$.ajax({url:"<?php echo e(route('admin.save.person')); ?>",method:"post",enctype:"multipart/form-data",processData:!1,cache:!1,contentType:!1,data:a,success:function(a){"true"==a.status&&(b+=`<tr id="${a.msg}"><td>${a.msg}</td><td>${$("#service_name").val()}</td><td><button class="table-buttons" onclick="getRow(${a.msg})"><ion-icon class="text-primary" name="create-outline"></ion-icon></button><button class="table-buttons" id='delete_service'><ion-icon class="text-danger" name="trash-outline"></ion-icon></button></td></tr>`,$("tbody").html(b),document.getElementById("form_save_service").reset(),$(".reset").click(),Swal.fire({position:"center",icon:"success",title:"Saved Person",showConfirmButton:!1,timer:1500}))}})}),$("body").on("click","#delete_service",function(){let a=$("input[name=\"_token\"]").val(),b=$(this).parents("tr").attr("id");Swal.fire({title:"Are you sure?",text:"You won't delete this service",icon:"warning",showCancelButton:!0,confirmButtonColor:"#3085d6",cancelButtonColor:"e#d33",confirmButtonText:"Yes, dlete it!"}).then(c=>{c.isConfirmed&&$.ajax({url:"<?php echo e(route('admin.delete.person')); ?>",method:"post",enctype:"multipart/form-data",data:{_token:a,service:b},success:function(a){$(`tr#${b}`).remove(),Swal.fire({position:"center",icon:"success",title:a.msg,showConfirmButton:!1,timer:1500})}})})}),$("#update_service").on("click",function(a){a.preventDefault();let b=new FormData($("#form_save_service")[0]);$.ajax({url:"<?php echo e(route('admin.update.person')); ?>",method:"post",enctype:"multipart/form-data",processData:!1,cache:!1,contentType:!1,data:b,success:function(a){"true"===a.status&&($(`tr#${rowId}`).find("td:nth-child(2)").text($("#service_name").val()),$("#save_service").removeClass("d-none"),$("#update_service").addClass("d-none"),document.getElementById("form_save_service").reset(),$(".reset").click(),Swal.fire({position:"center",icon:"success",title:a.msg,showConfirmButton:!1,timer:1500}))}})});function getRow(a){$.ajax({url:"<?php echo e(route('admin.get.update.person')); ?>",method:"post",enctype:"multipart/form-data",data:{_token,id:a},success:function(b){"true"===b.status&&(rowId=a,$("#save_service").addClass("d-none"),$("#update_service").removeClass("d-none"),$("#service_id").val(rowId),$("#email").val(b.msg.email),$("#service_name").val(b.msg.name),$("#discription").val(b.msg.note),$("#image").attr("title",b.msg.image),$("#item-image").html(`<label for="image" class="image unvisibile" data-label="Add Image" style="background-image:url(<?php echo e(URL::asset('Admin/Team')); ?>/${b.msg.image})"></label>`),window.scrollTo({top:0,behavior:"smooth"}))}})}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\portfolio\UTP-System\resources\views/admin/our_team.blade.php ENDPATH**/ ?>