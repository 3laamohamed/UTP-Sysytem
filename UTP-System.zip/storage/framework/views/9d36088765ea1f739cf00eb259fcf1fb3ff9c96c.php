<?php $title = 'Pages'; $check = "" ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <h2 class="title">View Data</h2>
    <form class="d-flex align-items-center justify-content-center view-form" id="save_form" action=" " method="POST" multiple enctype="multipart/form-data">

      <div class="form-check form-switch" style="font-size:25px">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($page->status == 1){$check="checked";} ?>
          <div>
            <input class="form-check-input" name="<?php echo e($page->page); ?>" type="checkbox" id="page-<?php echo e($page->page); ?>" vlaue='<?php echo e($page->status); ?>' <?php echo e($check); ?>>
            <label class="form-check-label" for="page-<?php echo e($page->page); ?>">
              <span style="font-size:25px"><?php echo e($page->page); ?></span>
            </label>
          </div>
          <?php $check = "" ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </form>
    <div class="d-grid gap-2 col-6 mx-auto">
      <button class="btn btn-success clicked" id="save_control_page" type="button">Save</button>
    </div>
  </div>

<script>
  let _token=$("input[name=\"_token\"]").val()
  $("#save_control_page").on("click",function(t){
    t.preventDefault();
    t=new FormData($("#save_form")[0]);
    let pages = []
    $('.form-check-input').each(function() {
      pages.push({
        name: $(this).attr('name'),
        value: $(this).is(":checked") ? 1 : 0
      })
    });
    $.ajax({
      url:"<?php echo e(route('admin.save_control_page')); ?>",
      method:"post",
      data: {
        _token,
        pages,
      },
      success:function(t){
        Swal.fire({
          position:"center",
          icon:"success",
          title:t.msg,
          showConfirmButton:!1,
          timer:1500
        })
      }
    })
  });
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\UTP-System\resources\views/admin/control_page.blade.php ENDPATH**/ ?>