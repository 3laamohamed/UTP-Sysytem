<?php
  $title = 'Projects';
?>

<?php $__env->startSection('content'); ?>
  <!-- Start Team Section -->
  <section class="Team py-5 position-relative">
    <div class="container">
      <h2 class="special-title">Our Projects</h2>
      <div class="row">
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 mb-3">
          <div class="card h-100">
            <div class="project-image">
              <img src="<?php echo e(asset('Admin/Projects/' . $project->image)); ?>" class="card-img-top" alt="Project">
            </div>
            <div class="card-body">
              <h5 class="card-title fw-bold"><?php echo e($project->title); ?></h5>
              <p class="project-text"><?php echo e($project->disc); ?></p>
              <button class="main-btn px-4 py-2 mt-2 show-project">Show More</button>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section>
  <!-- End Team Section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\portfolio\UTP-System\resources\views/main/project.blade.php ENDPATH**/ ?>