<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>
        <?php
        if(isset($title))
        {
        echo 'UTP | ' . $title;
        }
        else{
        echo 'UTP | System';
        }
//        ?>
    </title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <script src="<?php echo e(asset('global/js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Admin/js/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('Admin/js/touch.js')); ?>"></script>
    <script src="<?php echo e(asset('global/js/sweetalert2@10.js')); ?>"></script>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;900&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Admin/css/jquery-ui.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Admin/css/style.css')); ?>" rel="stylesheet">
</head>

<body>
    <div id="app">
      <?php if(Auth::user()): ?>
        <nav class="navbar navbar-expand-lg navbar-light shadow-sm">
            <div class="container">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav me-auto">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sort_projects')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.View_sort_projects')); ?>"> sort projects </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('projects')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.project')); ?>"> projects </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('details')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.details')); ?>"> details details </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('groups')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.group')); ?>"> projects group </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.clients')); ?>"> clients </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.contact')); ?>"> contact </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('copyright')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.copyright')); ?>"> copyright </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('social')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.general')); ?>"> Social </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('about')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.about')); ?>"> about </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('group_services')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.group_services')); ?>"> services Group </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('services')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.services')); ?>"> services </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_data')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.View_data')); ?>"> view data </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('control_page')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.View_control_page')); ?>"> control pages </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('our_team')): ?><li class="nav-item"><a class="nav-link" href="<?php echo e(Route('admin.View_our_team')); ?>"> our team </a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user')): ?><li><a class="nav-link" href="<?php echo e(route('users.index')); ?>">Users</a></li><?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role')): ?><li><a class="nav-link" href="<?php echo e(route('roles.index')); ?>">Role</a></li><?php endif; ?>
                  </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                        <!-- <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?> -->

                        <!-- <?php if(Route::has('register')): ?>

                            <?php endif; ?> -->
                        <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                              <a class="dropdown-item" href="<?php echo e(URL('Admin/update_user/user=' . Auth::user()->id)); ?>">
                                <?php echo e(__('Profile')); ?>

                              </a>
                              <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                   document.getElementById('logout-form').submit();">
                                  <?php echo e(__('Logout')); ?>

                              </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>

            </div>
        </nav>
      <?php endif; ?>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <script src="<?php echo e(asset('Admin/js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH E:\Xampp\htdocs\portfolio\UTP-System\resources\views/layouts/app.blade.php ENDPATH**/ ?>