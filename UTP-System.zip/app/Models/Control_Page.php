<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Control_Page extends Model
{
  use HasFactory;
  protected $table ='control_pages';
  protected $guarded = [];
}
